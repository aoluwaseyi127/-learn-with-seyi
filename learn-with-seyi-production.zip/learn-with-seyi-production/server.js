import express from 'express';
import helmet from 'helmet';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import pg from 'pg';
import crypto from 'crypto';
import path from 'path';
import { fileURLToPath } from 'url';

const { Pool } = pg;
const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET;
const DATABASE_URL = process.env.DATABASE_URL;
const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
if (!JWT_SECRET || !DATABASE_URL || !ADMIN_EMAIL) {
  console.error('Missing JWT_SECRET, DATABASE_URL or ADMIN_EMAIL environment variable.');
  process.exit(1);
}
const pool = new Pool({ connectionString: DATABASE_URL, ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized:false } : false });

app.use(helmet({ contentSecurityPolicy:false }));
app.use(express.json({ limit:'100kb' }));
app.use(express.static(__dirname, { extensions:['html'] }));

async function init(){
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id UUID PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'student' CHECK (role IN ('student','admin')),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      last_login_at TIMESTAMPTZ
    );
    CREATE TABLE IF NOT EXISTS progress (
      user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
      data JSONB NOT NULL DEFAULT '{}'::jsonb,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);
}
function tokenFor(u){ return jwt.sign({ sub:u.id, email:u.email, role:u.role }, JWT_SECRET, { expiresIn:'7d' }); }
function auth(req,res,next){
  try {
    const h=req.headers.authorization||''; if(!h.startsWith('Bearer ')) throw new Error();
    req.auth=jwt.verify(h.slice(7),JWT_SECRET); next();
  } catch { res.status(401).json({error:'Please log in again.'}); }
}
function admin(req,res,next){ if(req.auth?.role!=='admin') return res.status(403).json({error:'Admin access required.'}); next(); }
function safeUser(r){ return {id:r.id,name:r.name,email:r.email,role:r.role,created_at:r.created_at,last_login_at:r.last_login_at}; }

app.get('/api/ping',(req,res)=>res.json({ok:true}));
app.post('/api/signup',async(req,res)=>{
  try{
    const name=String(req.body.name||'').trim(), email=String(req.body.email||'').trim().toLowerCase(), password=String(req.body.password||'');
    if(name.length<2) return res.status(400).json({error:'Please enter your name.'});
    if(!/^\S+@\S+\.\S+$/.test(email)) return res.status(400).json({error:'Enter a valid email.'});
    if(password.length<8) return res.status(400).json({error:'Password must be at least 8 characters.'});
    const exists=await pool.query('SELECT id FROM users WHERE email=$1',[email]);
    if(exists.rowCount) return res.status(409).json({error:'This email already has an account — log in instead.'});
    const id=crypto.randomUUID(), hash=await bcrypt.hash(password,12), role=email===ADMIN_EMAIL?'admin':'student';
    const r=await pool.query('INSERT INTO users(id,name,email,password_hash,role,last_login_at) VALUES($1,$2,$3,$4,$5,NOW()) RETURNING id,name,email,role,created_at,last_login_at',[id,name,email,hash,role]);
    await pool.query('INSERT INTO progress(user_id,data) VALUES($1,$2)',[id,JSON.stringify({xp:0,seen:{},best:{},exam:{},lvl:{},wr:{}})]);
    res.status(201).json({token:tokenFor(r.rows[0]),...safeUser(r.rows[0]),progress:{xp:0,seen:{},best:{},exam:{},lvl:{},wr:{}}});
  }catch(e){ console.error(e); res.status(500).json({error:'Could not create the account.'}); }
});
app.post('/api/login',async(req,res)=>{
  try{
    const email=String(req.body.email||'').trim().toLowerCase(), password=String(req.body.password||'');
    const r=await pool.query('SELECT * FROM users WHERE email=$1',[email]);
    if(!r.rowCount || !(await bcrypt.compare(password,r.rows[0].password_hash))) return res.status(401).json({error:'Incorrect email or password.'});
    await pool.query('UPDATE users SET last_login_at=NOW() WHERE id=$1',[r.rows[0].id]);
    const p=await pool.query('SELECT data FROM progress WHERE user_id=$1',[r.rows[0].id]);
    res.json({token:tokenFor(r.rows[0]),...safeUser(r.rows[0]),progress:p.rows[0]?.data||{}});
  }catch(e){ console.error(e); res.status(500).json({error:'Could not log in.'}); }
});
app.post('/api/logout',auth,(req,res)=>res.json({ok:true}));
app.get('/api/me',auth,async(req,res)=>{ const r=await pool.query('SELECT * FROM users WHERE id=$1',[req.auth.sub]); if(!r.rowCount)return res.status(404).json({error:'Account not found.'}); res.json(safeUser(r.rows[0])); });
app.get('/api/progress',auth,async(req,res)=>{const r=await pool.query('SELECT data FROM progress WHERE user_id=$1',[req.auth.sub]);res.json(r.rows[0]?.data||{});});
app.put('/api/progress',auth,async(req,res)=>{const data=req.body||{}; await pool.query(`INSERT INTO progress(user_id,data,updated_at) VALUES($1,$2,NOW()) ON CONFLICT(user_id) DO UPDATE SET data=EXCLUDED.data,updated_at=NOW()`,[req.auth.sub,JSON.stringify(data)]);res.json({ok:true});});

app.get('/admin',auth,admin,(req,res)=>res.sendFile(path.join(__dirname,'admin.html')));
app.get('/api/admin/stats',auth,admin,async(req,res)=>{
  const [total,today,active,levels]=await Promise.all([
    pool.query('SELECT COUNT(*)::int AS n FROM users WHERE role=\'student\''),
    pool.query("SELECT COUNT(*)::int AS n FROM users WHERE role='student' AND created_at >= CURRENT_DATE"),
    pool.query("SELECT COUNT(*)::int AS n FROM users WHERE role='student' AND last_login_at >= NOW()-INTERVAL '7 days'"),
    pool.query("SELECT COUNT(*)::int AS n FROM progress")
  ]);
  res.json({total:total.rows[0].n,today:today.rows[0].n,active7d:active.rows[0].n,withProgress:levels.rows[0].n});
});
app.get('/api/admin/users',auth,admin,async(req,res)=>{
  const r=await pool.query(`SELECT u.id,u.name,u.email,u.role,u.created_at,u.last_login_at,p.data AS progress,p.updated_at AS progress_updated_at FROM users u LEFT JOIN progress p ON p.user_id=u.id ORDER BY u.created_at DESC`);
  res.json(r.rows.map(x=>({...safeUser(x),progress:x.progress||{}})));
});
app.get('/api/admin/users/:id',auth,admin,async(req,res)=>{
  const r=await pool.query(`SELECT u.id,u.name,u.email,u.role,u.created_at,u.last_login_at,p.data AS progress,p.updated_at AS progress_updated_at FROM users u LEFT JOIN progress p ON p.user_id=u.id WHERE u.id=$1`,[req.params.id]);
  if(!r.rowCount)return res.status(404).json({error:'User not found.'}); res.json({...safeUser(r.rows[0]),progress:r.rows[0].progress||{}});
});
app.delete('/api/admin/users/:id',auth,admin,async(req,res)=>{ if(req.params.id===req.auth.sub)return res.status(400).json({error:'You cannot delete your own admin account.'}); await pool.query('DELETE FROM users WHERE id=$1',[req.params.id]);res.json({ok:true}); });

app.use((req,res)=>res.sendFile(path.join(__dirname,'index.html')));
init().then(()=>app.listen(PORT,()=>console.log(`Learn with Seyi running on ${PORT}`))).catch(e=>{console.error(e);process.exit(1)});
