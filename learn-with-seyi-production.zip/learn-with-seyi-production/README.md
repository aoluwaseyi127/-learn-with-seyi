# Learn with Seyi — production version

This package keeps the existing learning website and adds:
- real server-side accounts
- PostgreSQL persistence
- bcrypt password hashing
- JWT authentication
- persistent learner progress
- admin-only dashboard at `/admin`
- user counts, activity, XP/level overview and account deletion

## Deploy
1. Create a PostgreSQL database.
2. Create a Node web service using this folder.
3. Set `DATABASE_URL`, `JWT_SECRET`, `ADMIN_EMAIL`, and `NODE_ENV=production`.
4. Build command: `npm install`
5. Start command: `npm start`
6. Open the deployed site. Create the admin account using the exact `ADMIN_EMAIL`; that account receives the admin role.
7. After login, open `/admin` for the dashboard.

The database tables are created automatically on first start.
