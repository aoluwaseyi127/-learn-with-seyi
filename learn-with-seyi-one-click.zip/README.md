# Learn with Seyi — one-click Render deployment

A mobile-friendly language-learning website with server-side accounts, PostgreSQL persistence, learner progress, and an admin dashboard.

## What is included
- Node.js + Express web server
- Real sign-up and login
- bcrypt password hashing
- JWT sessions
- PostgreSQL learner database
- Persistent learning progress
- Admin dashboard at `/admin`
- Render Blueprint (`render.yaml`) that creates the web service and PostgreSQL database together
- Automatic database table creation on first successful start
- `/api/ping` health check

## Deploy to Render
1. Put the contents of this folder in the root of your GitHub repository.
2. In Render, choose **New → Blueprint** and select the GitHub repository.
3. Render reads `render.yaml` and configures the Node web service and PostgreSQL database.
4. When prompted for `ADMIN_EMAIL`, enter the email address you want to use for the admin account.
5. Apply the Blueprint and wait for the deployment to finish.

The Blueprint generates `JWT_SECRET` automatically and connects `DATABASE_URL` to the PostgreSQL database. Do not commit `.env` or real secrets.

## Important about Render Free Postgres
Render's Free Postgres is useful for testing but expires after 30 days. Upgrade the database before then if you want to keep learner data long-term.

## Admin
Create an account using the exact `ADMIN_EMAIL` configured in Render. That account receives the `admin` role. Then visit `/admin` after logging in.
